package com.example.pr15_idrisov

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity2 : AppCompatActivity() {
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var textView: TextView
    private var currentQuest = 0;
    private lateinit var rightButton: Button
    private lateinit var leftButton: Button
    private val questions = arrayOf(
        "Реки крови наносит 76 единиц урона?",
        "Маргит, Ужасное знамение обязательный босс?",
        "Правда ли, что Ренни на самом деле не колдунья?",
        "Маления является самым легким боссом в игре?",
        "Повелитель Яростного пламени это худшая концовка в игре?",
        "Правда ли, что самый быстрый спидран по игре был равен 59 секунд и 27 милисекунд?",
        "Можно ли пройти Elden Ring за 20 часов?"
    )
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        trueButton = findViewById(R.id.true_button)
        falseButton = findViewById(R.id.false_button)
        textView = findViewById(R.id.quest1)
        rightButton = findViewById(R.id.rightb)
        leftButton = findViewById(R.id.leftb)
        textView.text = questions[currentQuest]
        trueButton.setOnClickListener { view: View ->
          checkAnswer(true)
        }
        falseButton.setOnClickListener { view: View ->
            checkAnswer(false)
        }
        rightButton.setOnClickListener { nextQuest() }
        leftButton.setOnClickListener { prevQuest() }
    }
    private fun nextQuest() {
        if (currentQuest < questions.size - 1) {
            currentQuest++
            textView.text = questions[currentQuest]
        } else {
            Toast.makeText(this, "Это последний вопрос", Toast.LENGTH_SHORT).show()
        }
    }
    private fun checkAnswer(userAnswer: Boolean) {
        val correctAnswers = arrayOf(
            true, true, false, false, true, true, false
        )

        if (userAnswer == correctAnswers[currentQuest]) {
            Toast.makeText(this, R.string.correct, Toast.LENGTH_SHORT).show()
            nextQuest()
        } else {
            Toast.makeText(this, R.string.incorrect, Toast.LENGTH_SHORT).show()
            nextQuest()
        }
    }
    private fun prevQuest() {
        if (currentQuest > 0) {
            currentQuest--
            textView.text = questions[currentQuest]
        } else {
            Toast.makeText(this, "Это первый вопрос", Toast.LENGTH_SHORT).show()
        }
    }

}